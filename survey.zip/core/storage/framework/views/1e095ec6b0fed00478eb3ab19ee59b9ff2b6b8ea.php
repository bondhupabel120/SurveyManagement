<script src="<?php echo e(asset('assets/backend/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/backend/datatables-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/backend/datatables-responsive/js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/backend/datatables-responsive/js/responsive.bootstrap4.min.js')); ?>"></script>
<?php /**PATH E:\PharmacySurvey\core\resources\views/backend/partials/datatable-js.blade.php ENDPATH**/ ?>