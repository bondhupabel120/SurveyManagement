<?php $__env->startSection('title'); ?>
    Add User
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content-wrapper" style="font-family: Roboto">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-12">
                        <h1 class="m-0 text-dark" style="font-family: kalpurush">Add User</h1>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card card-info">
                            <div class="card-header">
                                <h3 class="card-title" style="font-family: kalpurush">Add User</h3>
                                <div class="fa-pull-right">
                                    <a href="<?php echo e(route('manage.user')); ?>">
                                        <button class="btn btn-light"><i class="fa fa-arrow-left"></i><b> Back To User
                                                List</b></button>
                                    </a>
                                </div>
                            </div>
                            <form method="POST" action="<?php echo e(route('save.user')); ?>" enctype="multipart/form-data"
                                role="form">
                                <?php echo csrf_field(); ?>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Name <span class='required-star text-danger'>*</span></label>
                                                <input type="text" name="name"
                                                    class="form-control <?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>"
                                                    value="<?php echo e(old('name')); ?>" autofocus>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Mobile Number <span
                                                        class='required-star text-danger'>(Min:11,Max:11)*</span></label>
                                                <input type="text" name="phone"
                                                    class="form-control <?php echo e($errors->has('phone') ? ' is-invalid' : ''); ?>"
                                                    value="<?php echo e(old('phone')); ?>" autofocus>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Gender <span class='required-star'></span></label>
                                                <select name="gender" class="form-control">
                                                    <option value="1">Male</option>
                                                    <option value="2">Female</option>
                                                    <option value="3">Others</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Image <span class='required-star'></span></label>
                                                <input type="file" name="image"
                                                    class="form-control <?php echo e($errors->has('image') ? ' is-invalid' : ''); ?>"
                                                    value="<?php echo e(old('image')); ?>" accept="image/*" autofocus>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>E-Mail </label>
                                                <input type="email" name="email"
                                                    class="form-control <?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>"
                                                    value="<?php echo e(old('email')); ?>" autofocus>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Password <span class=' required-star text-danger'>*</span></label>
                                                <input type="password" name="password" id="myPassword"
                                                    class="form-control <?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>"
                                                    value="<?php echo e(old('password')); ?>" autofocus>
                                                    <div class="form-check">
                                                        <input class="form-check-input" type="checkbox" onclick="myPasswordFunction()" id="flexCheckDefault">
                                                        <label class="form-check-label" for="flexCheckDefault">
                                                            Show Password
                                                        </label>
                                                    </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Status <span class='required-star'></span></label>
                                                <select name="status" class="form-control">
                                                    <option value="1">Active</option>
                                                    <option value="0">Inactive</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-footer">
                                    <a href="<?php echo e(route('manage.user')); ?>">
                                        <button type="button" class="btn btn-danger">Close</button>
                                    </a>
                                    <button type="submit" class="btn btn-info float-right">Submit</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo $__env->make('backend.partials.password-show-hide', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PharmacySurvey\core\resources\views/backend/user/add-user.blade.php ENDPATH**/ ?>