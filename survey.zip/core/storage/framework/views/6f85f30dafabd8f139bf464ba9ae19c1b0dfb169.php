<!-- /.content-wrapper -->
<footer class="main-footer" style="text-align: center"><strong>Copyright &copy; <?php echo e(\Carbon\Carbon::now()->format('Y')); ?> <a href="javascript:void(0);">Pharmacy</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
        <b>Version</b> 1.0
    </div>

</footer>
<?php /**PATH E:\PharmacySurvey\core\resources\views/backend/partials/footer.blade.php ENDPATH**/ ?>