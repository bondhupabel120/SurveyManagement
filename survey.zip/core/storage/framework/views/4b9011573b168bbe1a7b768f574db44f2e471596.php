<?php $__env->startSection('title'); ?>
    Collected Data | <?php echo e($appName); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6" style="font-family: kalpurush">
                        <h1 class="m-0 text-dark">Collected Data</h1>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('user.dashboard')); ?>">Home</a></li>
                            <li class="breadcrumb-item active">Collected Data</li>
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>

        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card mt-3">
                            <div class="card-header">
                                <div class="fa-pull-left">
                                    <h3 class="card-title">
                                        <i class="fas fa-list"></i> Collected Data
                                    </h3>
                                </div>
                            </div>
                            <!-- /.card-header -->

                            <div class="card-body row">
                                <table id="table_id" class="table dt-responsive table-striped">
                                    <thead>
                                        <tr>
                                            <th>Question</th>
                                            <th>Survey Answer</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php ($i = 1); ?>
                                        <?php ($j = 1); ?>
                                        <tr>
                                            <td>
                                                <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php echo e($i++); ?>. <?php echo e($question->name); ?> <br> <hr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($answer_images->count() > 0): ?>
                                                    * Image
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php $__currentLoopData = $answer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $ans): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($question->id == $ans->question_id): ?>
                                                            <?php if($ans->question_id != ''): ?>
                                                                <?php echo e($j++); ?>. <?php echo e($ans->question_ans); ?> <br> <hr>
                                                            <?php else: ?>
                                                                <?php echo e($j++); ?>. null <br> <hr>
                                                            <?php endif; ?>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($answer_images->count() > 0): ?>
                                                    <?php $__currentLoopData = $answer_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer_image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($answer_image->image): ?>
                                                            <a href="<?php echo e(asset($answer_image->image)); ?>" target="_blank">
                                                                <img src="<?php echo e(asset($answer_image->image)); ?>" alt="Image" style="max-height: 100px">
                                                            </a>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PharmacySurvey\core\resources\views/backend/questionAnswer/single-survey.blade.php ENDPATH**/ ?>