<link rel="stylesheet" href="<?php echo e(asset('assets/backend/datatables-bs4/css/dataTables.bootstrap4.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/backend/datatables-responsive/css/responsive.bootstrap4.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/backend/css/datatable.css')); ?>">
<?php /**PATH E:\PharmacySurvey\core\resources\views/backend/partials/datatable-css.blade.php ENDPATH**/ ?>