<?php $__env->startSection('title'); ?>
    <?php echo e($user->name); ?>'s Profile
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content-wrapper" style="font-family: Roboto">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-12">
                        <h1 class="m-0 text-dark" style="font-family: kalpurush"><?php echo e($user->name); ?>'s Profile</h1>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card card-info">
                            <div class="card-header">
                                <h3 class="card-title" style="font-family: kalpurush"><?php echo e($user->name); ?>'s Profile</h3>
                            </div>
                            <div class="card-body">
                                <div class="row" id="included_all_description">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Name</label>
                                            <input type="text" value="<?php echo e($user->name); ?>" class="form-control" disabled>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Mobile Number </label>
                                            <input type="text" value="<?php echo e($user->phone); ?>" class="form-control" disabled>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>E-Mail</label>
                                            <input type="text" value="<?php echo e($user->email); ?>" class="form-control" disabled>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>User ID</label>
                                            <input type="text" value="<?php echo e($user->user_id); ?>" class="form-control" disabled>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Image</label>
                                            <?php if($user->image): ?>
                                                <a href="<?php echo e(asset($user->image)); ?>" target="_blank">
                                                    <img src="<?php echo e(asset($user->image)); ?>" alt="Image" style="max-width: 80px">
                                                </a>
                                            <?php else: ?>
                                                <img src="<?php echo e(asset('assets/backend/img/no_image_found.png')); ?>" alt="Image" style="max-width: 80px">
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Gender</label>
                                            <?php if($user->status == 1): ?>
                                                <button class="form-control text-left" disabled>Male</button>
                                            <?php elseif($user == 2): ?>
                                                <button class="form-control text-left" disabled>Female</button>
                                            <?php else: ?>
                                                <button class="form-control text-left" disabled>Others</button>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Status</label>
                                            <?php if($user->status == 1): ?>
                                                <button class="form-control text-left" disabled>Active</button>
                                            <?php else: ?>
                                                <button class="form-control text-left" disabled>Inactive</button>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PharmacySurvey\core\resources\views/user/user/profile.blade.php ENDPATH**/ ?>