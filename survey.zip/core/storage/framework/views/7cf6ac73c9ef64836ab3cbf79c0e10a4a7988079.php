<link rel="stylesheet" href="<?php echo e(asset('assets/admin/datatables-bs4/css/dataTables.bootstrap4.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/admin/datatables-responsive/css/responsive.bootstrap4.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/datatable.css')); ?>">


<script src="<?php echo e(asset('assets/admin/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/datatables-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/datatables-responsive/js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/datatables-responsive/js/responsive.bootstrap4.min.js')); ?>"></script>
<?php /**PATH E:\PharmacySurvey\core\resources\views/backend/partials/datatable.blade.php ENDPATH**/ ?>