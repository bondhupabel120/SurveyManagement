<!-- /.content-wrapper -->
<footer class="main-footer" style="text-align: center;margin-left: 0px!important"><strong>Copyright &copy; {{ \Carbon\Carbon::now()->format('Y') }} <a href="javascript:void(0);">Pharmacy</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
        <b>Version</b> 1.0
    </div>

</footer>
