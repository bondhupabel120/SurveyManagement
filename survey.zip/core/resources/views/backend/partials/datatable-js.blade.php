<script src="{{ asset('assets/backend/datatables/jquery.dataTables.min.js') }}"></script>
<script src="{{ asset('assets/backend/datatables-bs4/js/dataTables.bootstrap4.min.js') }}"></script>
<script src="{{ asset('assets/backend/datatables-responsive/js/dataTables.responsive.min.js') }}"></script>
<script src="{{ asset('assets/backend/datatables-responsive/js/responsive.bootstrap4.min.js') }}"></script>
